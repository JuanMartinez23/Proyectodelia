from django import forms
from .models import Producto, Pedido, Category
from django.contrib.auth.models import User

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'precio', 'stock', 'categoria']
        widgets = {
            'categoria': forms.Select(attrs={'required': 'required'}),
        }
    
    def __init__(self, *args, **kwargs):
        super(ProductoForm, self).__init__(*args, **kwargs)
        self.fields['categoria'].empty_label = "Seleccione..."
        
class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['productos']

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['nombre']
        labels = {
            'nombre': 'Nombre de la Categoría',
        }
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
        }
