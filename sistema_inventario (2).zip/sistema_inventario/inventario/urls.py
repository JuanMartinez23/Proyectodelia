from django.urls import path
from . import views

app_name = 'inventario'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('admin/products/', views.product_list, name='product_list'),
    path('gestion_productos/', views.gestion_productos_view, name='gestion_productos'),
    path('gestion/productos/agregar/', views.add_product, name='add_product'),
    path('productos/editar/<int:pk>/', views.product_edit, name='product_edit'),
    path('productos/eliminar/<int:pk>/', views.product_delete, name='product_delete'),
    path('categorias/', views.category_list, name='category_list'),
    path('categorias/crear/', views.category_create, name='category_create'),
    path('categorias/editar/<int:pk>/', views.category_edit, name='category_edit'),
    path('categorias/eliminar/<int:pk>/', views.category_delete, name='category_delete'),
    path('pedidos/nuevo/', views.order_create, name='order_create'),
    path('pedidos/add/<int:product_id>/', views.add_to_order, name='add_to_order'),
    path('home/', views.home, name='home'),
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('carrito/', views.view_cart, name='view_cart'),
    path('carrito/add/<int:producto_id>/', views.add_to_cart, name='add_to_cart'),
    path('carrito/update/<int:item_id>/', views.update_cart, name='update_cart'),
    path('carrito/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('carrito/confirmar/', views.confirm_order, name='confirm_order'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('user_management/', views.user_management, name='user_management'),
    path('create_order/', views.create_order, name='create_order'),
    path('view_cart/', views.view_cart, name='view_cart'),
    path('user/home/', views.user_home, name='user_home'),
    path('gestion/productos/', views.product_list, name='product_list'),
    path('editar/<int:product_id>/', views.edit_product, name='edit_product'),
    path('eliminar/<int:product_id>/', views.delete_product, name='delete_product'),
]