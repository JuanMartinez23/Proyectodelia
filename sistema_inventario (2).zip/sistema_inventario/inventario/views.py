from django.shortcuts import render, redirect, get_object_or_404
from .models import Producto, Category, Pedido, User,  CartItem
from .forms import ProductoForm, CategoryForm
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages

def dashboard(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('inventario:admin_dashboard')
        else:
            return redirect('inventario:create_order')
    return redirect('inventario:home')

def logout(request):
    auth_logout(request)
    return render(request, 'inventario/logout.html')

def product_list(request):
    if request.user.is_staff:
        productos = Producto.objects.all()
        return render(request, 'inventario/product_list.html', {'productos': productos})
    else:
        return redirect('inventario:home')

def product_create(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('inventario:product_list')
    else:
        form = ProductoForm()
    return render(request, 'inventario/product_create.html', {'form': form})

def product_edit(request, pk):
    product = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('inventario:product_list')
    else:
        form = ProductoForm(instance=product)
    return render(request, 'inventario/product_form.html', {'form': form})

def product_delete(request, pk):
    product = get_object_or_404(Producto, pk=pk)
    product.delete()
    return redirect('inventario:product_list')

def category_list(request):
    categories = Category.objects.all()
    return render(request, 'inventario/category_list.html', {'categories': categories})

def user_management(request):
    users = User.objects.all()
    return render(request, 'inventario/user_management.html', {'users': users})

def add_product(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventario:product_list')
    else:
        form = ProductoForm()
    return render(request, 'inventario/add_product.html', {'form': form})

def category_create(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventario:category_list')
    else:
        form = CategoryForm()
    return render(request, 'inventario/category_form.html', {'form': form})

def category_edit(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('inventario:category_list')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'inventario/category_form.html', {'form': form})

def category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk)
    category.delete()
    return redirect('inventario:category_list')

@login_required
def user_dashboard(request):
    products = Producto.objects.all()
    user_name = request.user.username
    return render(request, 'inventario/user_dashboard.html', {'products': products, 'user_name': user_name})

def home(request):
    context = {}
    if request.user.is_authenticated:
        context['is_admin'] = request.user.is_staff
        context['username'] = request.user.username
    return render(request, 'inventario/home.html', context)

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('inventario:home')
    else:
        form = AuthenticationForm()
    return render(request, 'inventario/login.html', {'form': form})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventario:login')
    else:
        form = UserCreationForm()
    return render(request, 'inventario/register.html', {'form': form})

def order_create(request):
    categories = Category.objects.all()
    selected_category = request.GET.get('category')
    filtered_products = Producto.objects.filter(categoria_id=selected_category) if selected_category else Producto.objects.all()
    return render(request, 'inventario/order_form.html', {'categories': categories, 'filtered_products': filtered_products})

def add_to_order(request, product_id):
    product = get_object_or_404(Producto, id=product_id)
    pedido, created = Pedido.objects.get_or_create(usuario=request.user)
    pedido.productos.add(product)
    return redirect('inventario:order_create')

def carrito(request):
    pedidos = Pedido.objects.filter(usuario=request.user)
    return render(request, 'inventario/carrito.html', {'pedidos': pedidos})

def admin_dashboard(request):
    return render(request, 'inventario/admin_dashboard.html')


def create_order(request):
    user_cart = CartItem.objects.filter(user=request.user)
    categories = Category.objects.all()
    productos = None

    if request.method == 'POST':
        categoria_id = request.POST.get('categoria')
        productos = Producto.objects.filter(categoria_id=categoria_id)

        if 'add_to_cart' in request.POST:
            producto_id = request.POST.get('producto_id')
            cantidad = int(request.POST.get('cantidad', 1))
            producto = Producto.objects.get(id=producto_id)

            cart_item, created = CartItem.objects.get_or_create(
                user=request.user, producto=producto, defaults={'cantidad': cantidad}
            )

            if not created:
                cart_item.cantidad += cantidad
                cart_item.save()

    return render(request, 'inventario/create_order.html', {
        'categories': categories, 'productos': productos
    })

def user_home(request):
    productos = Producto.objects.all()
    return render(request, 'inventario/user_home.html', {'productos': productos})



def view_cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total = sum(item.subtotal for item in cart_items)
    return render(request, 'inventario/carrito.html', {'cart_items': cart_items, 'total': total})

# Agregar producto al carrito
def add_to_cart(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    cart_item, created = CartItem.objects.get_or_create(user=request.user, product=producto)
    if not created:
        cart_item.cantidad += 1
    cart_item.save()
    return redirect('inventario:view_cart')

# Actualizar cantidad en carrito
def update_cart(request, item_id):
    if request.method == "POST":
        cart_item = get_object_or_404(CartItem, id=item_id)
        cart_item.cantidad = int(request.POST.get('cantidad', 1))
        cart_item.save()
    return redirect('inventario:view_cart')

# Eliminar producto del carrito
def remove_from_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id)
    cart_item.delete()
    return redirect('inventario:view_cart')

# Confirmar pedido
def confirm_order(request):
    CartItem.objects.filter(user=request.user).delete()  # Vaciar carrito tras confirmación
    messages.success(request, "Gracias por hacer su pedido.")
    return redirect('usuario:dashboard')
# Verifica si el usuario es administrador
def es_administrador(user):
    return user.is_staff

@login_required
@user_passes_test(es_administrador)  # Solo permite acceso a los administradores
def product_list(request):
    productos = Producto.objects.all()  # Obtiene todos los productos
    return render(request, 'inventario/product_list.html', {'productos': productos})

def edit_product(request, product_id):
    producto = get_object_or_404(Producto, id=product_id)
    if request.method == "POST":
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('inventario:product_list')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'inventario/edit_product.html', {'form': form, 'producto': producto})

# Vista para eliminar producto
def delete_product(request, product_id):
    producto = get_object_or_404(Producto, id=product_id)
    if request.method == "POST":
        producto.delete()
        return redirect('inventario:product_list')
    return render(request, 'inventario/delete_product.html', {'producto': producto})

def add_product_view(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventario:gestion_productos')  # Asegúrate de que este URL esté definido
    else:
        form = ProductoForm()
    return render(request, 'inventario/add_product.html', {'form': form})

def gestion_productos_view(request):
    productos = Producto.objects.all()
    return render(request, 'inventario/gestion_productos.html', {'productos': productos})

@login_required
def add_to_cart(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    cantidad = int(request.POST.get('cantidad', 1))
    cart_item, created = CartItem.objects.get_or_create(user=request.user, producto=producto)
    if created:
        cart_item.cantidad = cantidad
    else:
        cart_item.cantidad += cantidad
    cart_item.save()
    messages.success(request, "Producto añadido al carrito.")
    return redirect('inventario:view_cart')

# Ver el carrito
@login_required
def view_cart(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total = sum(item.producto.precio * item.cantidad for item in cart_items)
    return render(request, 'inventario/carrito.html', {'cart_items': cart_items, 'total': total})

# Confirmar pedido
@login_required
def confirm_order(request):
    CartItem.objects.filter(user=request.user).delete()  # Vaciar carrito tras confirmación
    messages.success(request, "Su pedido ha sido confirmado.")
    return render(request, 'inventario/confirm_order.html')

def update_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, user=request.user)
    cantidad = int(request.POST.get('cantidad', 1))
    if cantidad > 0:
        cart_item.cantidad = cantidad
        cart_item.save()
        messages.success(request, "Cantidad actualizada.")
    else:
        cart_item.delete()
        messages.info(request, "Producto eliminado del carrito.")
    return redirect('inventario:view_cart')

# Eliminar un producto del carrito
@login_required
def remove_from_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, user=request.user)
    cart_item.delete()
    messages.info(request, "Producto eliminado del carrito.")
    return redirect('inventario:view_cart')